# HEFIN - Decentralized Healthcare + Finance (ICP Prototype)

This repository contains a GitHub-ready scaffolding for the HEFIN project:
- Motoko canisters (canisters/*)
- Node.js bridge that writes to MongoDB (backend-node/*)
- Docker Compose to run MongoDB + bridge locally

## Structure
- canisters/: Motoko files for User, Health, Finance, Integration, Governance, Types
- backend-node/: Express + Mongoose bridge that accepts HTTP sync calls and persists data to MongoDB
- docker-compose.yml: bring up mongo + bridge

## Local development
1. Start Docker:
   ```bash
   docker-compose up --build
   ```
2. Build & deploy canisters locally (requires dfx):
   ```bash
   cd canisters
   dfx start --background
   dfx deploy
   ```
3. Use IntegrationCanister.demoSync to post test payloads to `http://localhost:3000/sync/health`

## Notes
- Motoko cannot call MongoDB directly. IntegrationCanister demonstrates HTTP outcalls to the bridge.
- This scaffold is for development/demo. Security, authentication, encryption, and production hardening are required before any real deployment.

